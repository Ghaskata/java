class CirList {
    static class Node{
        int data ;
        Node next;
    };
    static Node empty(Node last,int data){
        if(last != null){
           // return ;
        }
        // new node create 
        Node newnode = new Node();
        // assign data into newnode
        newnode.data = data;
        // point reffrence
        last = newnode;
        newnode.next = last;
        return last;
    }
    static Node front(Node last,int data){
        if(last == null) {
            //return ;
        }
        Node newnode = new Node();
        newnode.data = data;
        newnode.next = last.next;
        last.next = newnode;
        return last;    
    }
    static Node end(Node last,int data){
        if(last == null){}
           //return end(last,data);
        Node newnode = new Node();
        newnode.data=data;
        newnode.next=last.next;
        last.next = newnode;
        last = newnode;
        return last;
    }
    static Node position(Node last,int data,int item){
        if(last==null){}
           //return position(last, data,item);
        Node p , newnode;
        p = last.next;
        do {
            if(p.data==item) {
                newnode = new Node();
                newnode.data = data;
                newnode.next = last.next;
                last.next = newnode;
                if(p == last){
                    last = newnode;
                }
            }
            p = p.next;
        }while(p != last.next);
        System.out.println("givin item is not in list ");
        return last;  
    }
    //print
    static void print(Node last){
        Node p ;
        if(last==null){
            System.out.println("list is empty");
            //return print(last);
        }
        p= last.next;
        do{
           System.out.println(p.data);
           p=p.next;
        }while(p != last.next);
    }
    public static void main(String args[]){
        //CirList c = new CirList();
        Node last = null;
        last = empty(last,10);
        print(last);
        last = empty(last,20);
        print(last);
        last = front(last,30);
        print(last);
        last = end(last,40);
        print(last); 
        
    }
}
