import java.awt.*;
import java.applet.*;

/* <applet code="Shape" width=500 height=700> </applet> */

public class Shape extends Applet {
         public void paint(Graphics g){
            Font f = new Font("cursiv",Font.BOLD,30);
            g.setFont(f);
            int x[] = {120,220,30};
            int y[] = {30,220,220};
            g.setColor(Color.blue);
            g.fillOval(8,30,235,235);
            g.setColor(Color.yellow);
            g.fillPolygon(x,y,3);
            g.setColor(Color.blue);
            g.drawString("hello",90,150);
         }
}
