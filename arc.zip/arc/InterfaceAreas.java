import java.util.*;
interface Area
{
    void area();
    Scanner s = new Scanner(System.in);
}
class Reactangle implements Area 
{
    public void area(){
        System.out.println("enter the height and  bace of rectangle :  ");
        float b = s.nextFloat();
        float h = s.nextFloat();
        System.out.println(b*h);
    }
}
class Circle implements Area 
{
    public void area(){
        System.out.println(" Enter the redius of circle : ");
        float r = s.nextFloat();
        System.out.println(r*r*3.14);
    }
}
class Triangle implements Area 
{
    public void area(){
        System.out.println("enter the height and length of tringle :  ");
        float l = s.nextFloat();
        float h = s.nextFloat();
        System.out.println(h*l*0.5);
    }
}

public class InterfaceAreas {
    public static void main(String args[]) {
        Reactangle r = new Reactangle();
        Circle c = new Circle();
        Triangle t = new Triangle();
        r.area();
        c.area();
        t.area();
    }
}
