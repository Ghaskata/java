//create STUDENT class having data members no and name. Create 5 objects of STUDENT class take input from the user and print all students' data and in ascending order of name with interval of 1 second.

import java.util.Scanner;
import java.io.*;
import java.lang.Thread;

public class stud extends Thread
{
    int rno, s;
    int n[] = new int[5];
    String a[] = new String[5];
    String name, p;
    public void get()
    {
        for(int i=0; i<5; i++)
        {
            System.out.print("Enter Rno: ");
            Scanner s = new Scanner(System.in);
            n[i] = s.nextInt();
            System.out.print("Enter Name: ");
            Scanner p = new Scanner(System.in);
            a[i] = p.nextLine();
        }
    }    
    public void put()
    {
        for(int i=0; i<5; i++)
        {
            Thread t = new Thread(this);
            System.out.print("    Rno: " + n[i]);
            System.out.println("   Name: " + a[i]);
            try{
            t.sleep(1000);
            }
            catch(InterruptedException e) {}
        }
    }    
    public static void main(String args[])
    {
        stud s = new stud();
        s.get();        
        s.put();            
    }
};
