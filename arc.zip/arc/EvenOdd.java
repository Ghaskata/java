public class EvenOdd {
    public static void main(String args[]) {
        try{
            for(int i=0 ; i<args.length ; i++){
                System.out.println(args[i]);
            }
            int n1 = Integer.parseInt(args[0]);
            int n2 = Integer.parseInt(args[1]);
            int sumeven =0;
            int sumodd = 0;
            for(int i=n1;i<=n2;i++){
                if(i%2==0){
                    sumeven += i;
                }
                else{
                    sumodd += i;
                }
            }
            System.out.println("                                     ");
            System.out.println("sum of odd numbers = " + sumodd);
            System.out.println("                                     ");
            System.out.println("sum of even number =  " + sumeven);
        }
        catch(Exception e){

        }
    }
}
