public class IndividualDigit extends Thread{
    public static void main(String args[]){
        try{
            Thread t = new Thread();
            int temp = 0;
            for(int i=0 ; i<args.length ; i++){
                System.out.println("argument number is : "+args[i]);
                temp += Integer.parseInt(args[i]);
            }
            String s = args[0];
            for(int i = 0 ; i<s.length() ; i++){
                t.sleep(3000);
                System.out.println(s.charAt(i));
            }
        }
        catch(Exception e){
             System.out.println(e);
        }
    }
}
