import java.awt.*;
import java.applet.*;

/* <applet code="polygon" width=500 height=700> </applet> */

public class polygon extends Applet {
    public void paint(Graphics g){
        int x[] = {500,375,450,600,650};
        int y[] = {500,600,750,750,600};
        
        g.setColor(Color.yellow);
        g.fillOval(350,450,350,350);
        g.setColor(Color.blue);
        g.fillPolygon(x,y,5);
        
    }
}