class Node {
    int data;
    Node next;
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class singlyLinkedList {
    Node start;
        public void insert(int data) {
            Node current = start;
            while(current.next != null) {
                current = current.next;
            }
            Node newNode = new Node(data);
            current.next = newNode;
        }
        public void print() {
            Node current = start ;
            while(current.next!=null) {
                System.out.println(current.data);
                current=current.next;
            }
            System.out.println(current.data);
        }
        public void delete(int data){
            if(data == start.data){
               start = start.next;
               return;
            }
            Node current = start;
            while(current.next.data != data) {
                current = current.next;
            }
            current.next = current.next.next;
            System.out.println("deleted data is = "+data);
        }
        public void search(int data) {
            int p = 0;
            Node current = start;
            while(current != null) {
                if (current.data == data) {
                    System.out.println("position is "+p+" of this data "+data);
                }
                current=current.next;
                p++;
            }
        }
        public static void main(String args[]){
            singlyLinkedList s = new singlyLinkedList();
            s.start = new Node(10);
            s.insert(20);
            s.insert(30);
            s.insert(40);
            s.insert(50);
            s.insert(60);
            s.print();
            s.delete(60);
            s.search(30);
            s.print();
        }        
}