import java.awt.*;
import java.applet.*;

/* <applet code="Smiley1" width=600 height=400></applet> */

public class Smiley1 extends Applet {
    public void paint(Graphics g){
        /*g.setColor(Color.yellow); */
        g.drawOval(400,200,300,300);
        g.fillOval(475,250,40,40);
        g.fillOval(575,250,40,40);
        g.drawLine(550,350,550,400);
        g.fillArc(500,400,100,70,180,180);
    }
}