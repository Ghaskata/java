class Node {
    int data ;
    Node next ;
    Node(int data){
       this.data = data;
       this.next = null;
    }
}

public class SingleList{

    Node start;
    public void add(int data){
        Node current = start ;
        while(current.next != null){
            current = current.next;
        }
        Node newnode = new Node(data);
        current.next = newnode;
    }
    public void print(){
        Node current = start ;
        while(current.next != null){
            System.out.println(current.data);
            current = current.next;
        }
        System.out.println(current.data);
    }
    public void delete(int data){
        Node current = start ;
        if(start.data == data){
            start = start.next;
        }
        while(current.next.data!=data){
              current = current.next;
        }
        current.next = current.next.next;
        System.out.println(data); 
    }
    public void find(int data){
        Node current = start;
        int p = 0;
        while(current.next != null) {
        if(current.data == data){
            
                System.out.println("data index : "+p);
        }
        current = current.next;
        p++;
    }
    }
    public static void main(String args[]){
        SingleList s = new SingleList();
        s.start = new Node(10);
        s.add(20);
        s.add(30);
        s.add(40);
        s.print();
        s.delete(30);
        s.print();
        s.find(20);
        s.print();
    }
}
