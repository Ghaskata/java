class Node {
      int data;
      Node next;
      Node(int data){
        this.data=data;
        this.next=null;
      }
}
public class List {
    Node start;
    public void add(int data){
         Node current = start;
         while(current.next != null){
            current=current.next;
         }
         Node newnode = new Node(data);
         current.next = newnode;
    }
    public void display(){
        Node current = start;
        while(current.next != null){
            System.out.println(current.data);
            current = current.next;
        }
        System.out.println(current.data);
    }
    public void delete(int data){
        Node current = start;
        if(start.data == data){
            start = start.next;
        }
        while(current.next.data != data){
              current=current.next;
        }
        System.out.println("deleted element is = "+data);
        current.next = current.next.next;
    }
    public void find(int data) {
        Node current = start;
        int p = 0;
        while(current.next != null){
            if(current.data == data){
               System.out.println("index value is : "+p);
            }
            current= current.next;
            p++;
        }
    }

    public static void main(String args[]){
        List l = new List();
        l.start = new Node(10);
        l.add(20);
        l.add(30);
        l.add(40);
        l.add(50);
        l.display();
        l.delete(50);
        l.display();
        l.find(30);
        l.display();
    }
}
