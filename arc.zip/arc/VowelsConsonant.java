import java.util.*;
public class VowelsConsonant {
    public static void main(String args[]){
        try{
            Scanner s = new Scanner(System.in);
            System.out.println("   Enter the string  =  ");
            String str = s.next();
            
            int v = 0 , c = 0;
    
            for(int i=0;i<str.length();i++){
    
                if(str.charAt(i)=='A' || str.charAt(i)=='E' || str.charAt(i)=='I' || str.charAt(i)=='O' || str.charAt(i)=='U' ||
                   str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' || str.charAt(i)=='u') 
                {
                    v++;
                }
                else 
                {
                    c++;
                }
            }
            System.out.println("  " + str + "  in Total  vowels is : " + v);
            System.out.println("  " + str + "  in Total  consonants is : " + c);
        }
        catch(Exception e){

        }
        
    }
}
