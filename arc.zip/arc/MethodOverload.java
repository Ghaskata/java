class sum {
    void add(){
        System.out.println("concat the string and add 2 number is : ");
    }
    void add(int a,int b){
        System.out.println(a+b);
    }
    void add(String s1,String s2){
        System.out.println(s1.concat(" "+s2));
    }
}
public class MethodOverload {
    public static void main(String args[]){
        for(int i=0;i<args.length;i++){
            System.out.println("the commandline argument is  ["+ i +"] : "+args[i]);
        }
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        String s1 = args[2];
        String s2 = args[3];
        sum s = new sum();
        s.add();
        s.add(a,b);
        s.add(s1,s2);
    }
}
