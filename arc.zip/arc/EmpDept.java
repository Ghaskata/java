class Dept{
    int Deptno ;
    String Deptname;
    public Dept(int Deptno,String Deptname){
      this.Deptno = Deptno;
      this.Deptname = Deptname;
    }
}
class Emp extends Dept{
    int Empno;
    String Empname;
    int Esal;
    String Edesignetion;

    public Emp(int Deptno,String Deptname,int Empno, String Empname, int Esal, String Edesignetion)
    {
        super(Deptno,Deptname);
        System.out.println(Empname + "      " + Esal + "       " + Deptname + "        " + Edesignetion);
        System.out.println("");    
    }
}
public class EmpDept {
    public static void main(String args[]){
       // Scanner s = new Scanner(System.in);
        Emp e[] = new Emp[5];
        e[0] = new Emp(1,"IT",101,"Arpan",500000,"CEO");
        e[1] = new Emp(2,"FAINANCE",102,"Tmu",400000,"manager");
        e[2] = new Emp(3,"ECONOMICS",103,"jeet",80000,"manager");
        e[3] = new Emp(4,"Auditing",104,"git",20000,"clerk");
        e[4] = new Emp(5,"Sales",105,"Meet",50000,"manager");
    }
}

