import java.io.*;
import java.util.*;
public class SortOneString{
    public static void main(String args[]) throws Exception {
        Scanner s = new Scanner(System.in);
        System.out.println("enter one word : ");
        String s1 = s.next();
        char c[] = s1.toCharArray();
        char temp;
        for(int i=0 ; i< c.length ; i++){
            for(int j=i+1 ; j< c.length ; j++){
                if(c[j] > c[i]){
                    temp = c[i];
                    c[i] = c[j];
                    c[j] = temp;
                }
            }
        }
        System.out.println(c);
    }
}
