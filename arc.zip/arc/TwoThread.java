import java.util.*;
class Even extends Thread
{
    int n1;
    int n2;
    Even(int n1,int n2)
    {       
        this.n1 = n1;  
        this.n2 = n2;
    }
    public void run()
    {
        try{
            //System.out.println("Even number Givin belove : ");
            for(int i=n1;i<=n2 ;i++){
                if(i%2==0){
                    System.out.println("    "+ "Even = " + i);
                    Thread.sleep(1000);
                }
            }
        }
        catch(Exception e){}
    }
}
class Odd extends Thread
{
    int n1,n2;
    Odd(int n1,int n2){
        this.n1 = n1;
        this.n2 = n2;
    }
    public void run(){
        try{
            //System.out.println("odd number Givin belove : ");
            for(int i=n1;i<=n2 ;i++){
                if(i%2!=0){
                    System.out.println("    "+ "Odd = " + i);
                    Thread.sleep(1000);
                }
            }
        }
        catch(Exception e){}
    }
}
public class TwoThread {
    public static void main(String args[]){
        System.out.println();
        System.out.println("Even and Odd between " + args[0] + " to " + args[1] + " is : ");
        int n1 = Integer.parseInt(args[0]);
        int n2 = Integer.parseInt(args[1]);

        Even e = new Even(n1,n2);
        Odd o = new Odd(n1,n2);

        e.start();
        o.start();
    }
}
