import java.awt.*;
import java.applet.*;

/* <applet code="simley" width=600 height=400></applet> */

public class smiley extends Applet {
    public void paint(Graphics g){
        g.setColor(Color.yellow);
        g.fillOval(430,188,246,238);
        g.fillOval(519,301,26,38);
        g.fillOval(586,277,26,38);
        g.drawLine(548,333,4,10);
        g.fillArc(520,250,40,30,180,180);

    }
}