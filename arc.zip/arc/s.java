import java.awt.*;
import java.applet.*;

/* <applet code="s" width=500 height=700> </applet> */

public class s extends Applet {
         public void paint(Graphics g){
            int x[] = {120,220,30};
            int y[] = {30,220,220};
            
            g.fillPolygon(x,y,3);
            //g.drawString("hello",250,350);
         }
}
