import java.awt.*;
import java.applet.*;
/* <applet code="StringBanner" width=1000 height=600> </applet> */
public class StringBanner extends Applet implements Runnable {
    String s = " Arpan :)  ";
    Thread t = null;
    Font f = new Font(null,Font.BOLD,40);
    boolean move = false;
    int x = 10;
    public void init()
    {
        setBackground(Color.yellow);
        setForeground(Color.blue);
        setFont(f);
    }
    public void start()
    {
       t = new Thread(this);
       t.start();
       move=true;
    }
    public void run()
    {
        while(move == true) {
            try {
                repaint();
                t.sleep(100); 
            }
            catch(Exception e){ }
        }
    }
    public void stop()
    {
       move = false;
    }
    public void paint(Graphics g)
    {
        x += 25;
        if(x>2000)
        {
            x = 10 ;
        }
        g.drawString(s,x,400);
    }
}
