/*import java.util.*;
public class Stack {
    public static void main(String args[]){
        Stack stc = new Stack();
        Scanner s = new Scanner(System.in);
        System.out.println("enter number ");
        int n1 = s.nextInt();
        stc.push(n1);
        boolean r = stc.empty();
        System.out.println(r);
    }
}*/
import java.util.Stack;

class Main {
    public static void main(String[] args) {
        Stack<String> animals= new Stack<>();

        // Add elements to Stack
        animals.push("Dog");
        animals.push("Horse");
        animals.push("Cat");
        System.out.println("Initial Stack: " + animals);

        // Remove element stacks
        String element = animals.pop();
        System.out.println("Removed Element: " + element);
    }
}