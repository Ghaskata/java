public class PaliString {
    public static void main(String args[]){
        StringBuffer str = new StringBuffer(args[0]);
        str.reverse();
        String s1 ;
        s1.append(str);

        if(){
            System.out.println("given string is palindrome " + s1);
        }
        else {
            System.out.println("not");
        }
    }
}
