import java.applet.*;
import java.awt.*;
/* <applet code = Pictures  width=400 height=500> </applet> */
public class Pictures extends Applet{
    public void paint(Graphics g){
        Font f = new Font("cursive",Font.BOLD,50);
        int x[] = {550,350,425,670,745};
        int y[] = {200,350,570,570,350};
        g.setColor(Color.blue);
        g.fillPolygon(x,y,5);
        g.setColor(Color.yellow);
        g.fillOval(380,243,332,332);
        g.setColor(Color.blue);
        g.setFont(f);
        g.drawString("Hello",450,425);

        int x1[] = {1058,891,955,1163,1225};
        int y2[] = {230,350,545,545,350};
        g.setColor(Color.blue);
        g.fillOval(885,230,352,352);
        g.setColor(Color.yellow);
        g.fillPolygon(x1,y2,5);
        g.setColor(Color.blue);
        g.setFont(f);
        g.drawString("Applet",950,425);
    }
}
