
public class StringMethods {
     public static void main(String args[]){

           StringBuffer str = new StringBuffer("tmu");
        
           System.out.println(str);
        
           System.out.println("Reverse of the main string : "+str.reverse());
        
           System.out.println("=============================="); 
        
           String s = "                Archana   ";
           System.out.println(s);
           //System.out.println(s.length());        
           System.out.println(s.toUpperCase());

           System.out.println(s.trim());
           //System.out.println(s.length());
    
           System.out.println(str.equals(s));
    }
}