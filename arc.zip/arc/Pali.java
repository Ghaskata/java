public class Pali {
    public static void main(String args[]){
        try {

            for(int i=0 ; i<args.length;i++){
                System.out.println(args[i]);
            }
            String s = args[0];
            int num = Integer.parseInt(s);
            int rem = 0;
            int rev=0;
            int temp = num;
            while(temp>0){
                rem = temp % 10 ;
                rev = rev*10 +rem;
                temp = temp / 10;
            }
            if(rev==num) {
                System.out.println("Giving number is palindrome ");
            }
            else {
                System.out.println("Giving number is not palindrome");
            }

        }
        catch(Exception e) {

        }
    }    
}
