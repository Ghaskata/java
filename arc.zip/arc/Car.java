import java.awt.*;
import java.applet.*;

/* <applet code="Car" width=500 height=400></applet> */ 
public class Car extends Applet implements Runnable{
    int x = 10;
    public void init() {
        setBackground(Color.yellow);
    }
    public void start() {
        Thread t = new Thread(this);
        t.start();
    }
    public void run(){
        while(true){
            repaint();
            try{
                Thread.sleep(100);
            }
            catch(Exception e){ }
        }
    }
    public void paint(Graphics g){
       x++;
       if(x>1500){
        x = 10;
       }
       g.setColor(Color.blue);
       g.fillOval(x+20,350,100,80);
       g.fillRect(x+10,390,200,60);
    }
}
