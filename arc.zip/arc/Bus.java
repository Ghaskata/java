import java.awt.*;
import java.applet.*;

/* <applet code="Bus" width=700 height=800 ></applet>*/
public class Bus extends Applet implements Runnable{
    int x = 10;
    //boolean move=false;
    public void init(){
        setBackground(Color.yellow);
        setForeground(Color.blue);
    }   
    public void start() {
        Thread t = new Thread(this);
        t.start();
    }
    public void run(){
        while(true){
            repaint();
        try{
           Thread.sleep(100);
        }
        catch(Exception e) { }
    }
    }
    public void paint(Graphics g){
        x+=50;
        if(x>500){
            x = 10;
        }
        g.fillRect(x+10, 100, 200, 115);
        g.fillOval(x+40,210,50,50);
        g.fillOval(x+100,210,50,50);
    }
}
